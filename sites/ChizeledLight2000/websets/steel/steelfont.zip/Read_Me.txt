The font contained in this archive is Freeware.
No payment is required for the use of this font.  It's free!

I make a new font every week and post it on my website.

Ray Larabie's Freeware Typeface of the Week
www.delirium.com/larabiefonts

If you'd like to make a donation I'd be more than happy to accept it!  :-)
www.delirium.com/larabiefonts/donation.htm

Ray Larabie

fonts@imail.org